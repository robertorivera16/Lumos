
public class Sector {
	public String name;
	public boolean water;
	public boolean power;
	public Sector(String name) {
		this.name = name;
	}
}